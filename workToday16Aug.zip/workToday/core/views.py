
from django.core.exceptions import ObjectDoesNotExist
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.decorators import api_view
from django.middleware.csrf import get_token
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import login, logout
from rest_framework import status
from datetime import datetime, timedelta
from .serializers import *
from .models import *
import base64
import pyotp
from django.db.models import Q
import binascii
import os

# get csrf token
@api_view(['GET'])
def csrf(request):
	return Response({'csrfToken':get_token(request)})

def generateToken():
    return binascii.hexlify(os.urandom(20)).decode()

class generateKey:
    @staticmethod
    def returnValue(phone):
        return str(phone) + str(datetime.date(datetime.now())) + "Some Random Secret Key"

# Time after which OTP will expire
EXPIRY_TIME = 120 # seconds

class OrganizationList(APIView):
    @staticmethod
    def post(request):
        qs = Organization.objects.all()
        ser = OrganizationSerializer(qs, many=True).data
        return Response({"status":"200","message":"Organizations List","res":ser},status=200)

class WorkPlaceRegistration(APIView):
    @staticmethod
    def post(request):
        try:
            phone = request.data['phone']
            try:
                obj = Workplace.objects.get(phone=phone)
                if obj.is_active == True:
                    keygen = generateKey()
                    key = base64.b32encode(keygen.returnValue(phone).encode())
                    OTP = pyotp.TOTP(key,interval = EXPIRY_TIME)
                    print(OTP.now())
                    return Response({'status':'200','message':'OTP sent successfully','mobile':phone,"OTP": OTP.now()}, status=200)
                return Response({'message':'Your account is not active, Please contact to Admin','status':'201'}, status=200)
            except ObjectDoesNotExist:
                keygen = generateKey()
                key = base64.b32encode(keygen.returnValue(phone).encode())
                OTP = pyotp.TOTP(key,interval = EXPIRY_TIME)
                print(OTP.now())
                return Response({'status':'200','message':'OTP sent successfully','mobile':phone,"OTP": OTP.now()}, status=200)
        except KeyError:
            return Response({'status':'400','message':'Phone number is required'}, status=400)

class Verify_OTP(APIView):
    # This Method verifies the OTP
    @staticmethod
    def post(request):
        try:
            phone=request.data['phone']
            otp = request.data["otp"]
        except KeyError:
            return Response({"status":"404",'message':"Phone Number and OTP is required",}, status=404)
        try:
            keygen = generateKey()
            key = base64.b32encode(keygen.returnValue(phone).encode())  # Generating Key
            OTP = pyotp.TOTP(key,interval = EXPIRY_TIME)  # TOTP Model 
            if OTP.verify(otp):  # Verifying the OTP
                obj = Workplace.objects.get(phone=phone)
                tgen = generateToken()
                obj.token = tgen
                obj.save()
                ser = WorkplaceSerializer(obj).data
                return Response({"status":"200","message":"Logged In Successfully","type":"exist","res":ser}, status=200)
            return Response({"status":"400",'message':"OTP is wrong/expired",}, status=400)
        except ObjectDoesNotExist:
            obj = Workplace.objects.create(phone=phone)
            if obj is not None:
                tgen = generateToken()
                obj.token = tgen
                obj.save()
                ser = WorkplaceSerializer(obj).data
                return Response({"status":"201",'message':"User registered","type":"new","res":ser}, status=201)
            else:
                print('error')

class LogOutWorkplace(APIView):
    @staticmethod
    def post(request):
        try:
            obj = Workplace.objects.get(id=request.data['id'])
            obj.token=" "
            obj.save()
            return Response({"message":"Logout Successfull"},status=200)
        except:
            return Response({"message":"Invalid Details"},status=400)

class UpdateWorkplace(APIView):
    @staticmethod
    def post(request):
        try:
            id = request.data['id']
            token = request.data['token']
            obj = Workplace.objects.get(id=id,token=token)
            orgobj = Organization.objects.get(id=request.data['organization'])
            ser = WorkplaceSerializer(obj,data=request.data, partial=True)
            if ser.is_valid():
                ser.save(organization=orgobj)
                return Response({"message":"Workplace created successfully","res":ser.data},status=200)
            return Response(ser.errors,status=400)
        except(ObjectDoesNotExist,KeyError,ValueError):
            return Response({"message":"Invalid Details",},status=400)

class WorkplaceDetails(APIView):
    @staticmethod
    def post(request):
        try:
            wobj = Workplace.objects.get(id=request.data['id'],token = request.data['token'])
            ser = WorkplaceSerializer(wobj)
            return Response({"message":"Workplace Details","res":ser.data},status=200)
        except:
            return Response({"message":"Invalid Details"},status=400)

class DeleteWorkplace(APIView):
    @staticmethod
    def post(request):
        try:
            wobj = Workplace.objects.get(id=request.data['id'])
            wobj.delete()
            return Response({"message":"Workplace Delete",},status=200)
        except:
            return Response({"message":"Invalid Details"},status=400)

class AddEmployee(APIView):
    @staticmethod
    def post(request):
        try:
            email = request.data['email']
            Employee.objects.get(email=email)
            return Response({"message":"Email already used"},status=200)
        except(ObjectDoesNotExist,KeyError,ValueError):
            try:
                wobj = Workplace.objects.get(id=request.data['workplace'],token = request.data['token'])
            except:
                return Response({"message":"Invalid Details"},status=400)
            ser = EmployeeSerializer(data=request.data)
            if ser.is_valid():
                ser.save(workplace=wobj)
                return Response({"message":"Employee added successfully"},status=200)
            return Response(ser.errors,status=400)

class EmployeeList(APIView):
    @staticmethod
    def post(request):
        try:
            wobj = Workplace.objects.get(id=request.data['id'])
            eqs = Employee.objects.filter(workplace=wobj)
            ser = EmployeeSerializer(eqs,many=True)
            return Response({"message":"Employee List","res":ser.data},status=200)
        except:
            return Response({"message":"Invalid Details"},status=400)

class EmployeeDetails(APIView):
    @staticmethod
    def post(request):
        try:
            obj = Employee.objects.get(id=request.data['id'],token = request.data['token'])
            ser = EmployeeSerializer(obj)
            return Response({"message":"Employee Details","res":ser.data},status=200)
        except:
            return Response({"message":"Invalid Details"},status=400)

class UpdateEmployee(APIView):
    @staticmethod
    def post(request):
        try:
            obj = Employee.objects.get(id=request.data['id'],token = request.data['token'])
            ser = EmployeeSerializer(obj,data=request.data,partial=True)
            if ser.is_valid():
                ser.save()
                return Response({"message":"Details Updated","res":ser.data},status=200)
            return Response(ser.errors,status=400)
        except:
            return Response({"message":"Invalid Details"},status=400)

class EmployeeLogin(APIView):
    @staticmethod
    def post(request):
        try:
            obj = Employee.objects.get(email=request.data['email'])
            if obj.password == request.data['password']:
                tgen = generateToken()
                obj.token = tgen
                obj.save()
                ser = EmployeeSerializer(obj).data
                return Response({"message":"Logged in successfully","res":ser},status=200)
            return Response({"message":"Invalid Password"},status=400)
        except:
            return Response({"message":"Invalid email id"},status=400)

class LogOutEmployee(APIView):
    @staticmethod
    def post(request):
        try:
            obj = Employee.objects.get(id=request.data['id'])
            obj.token=" "
            obj.save()
            return Response({"message":"Logout Successfull"},status=200)
        except:
            return Response({"message":"Invalid Details"},status=400)


# Task Apis
class CreateTask(APIView):
    @staticmethod
    def post(request):
        try:
            wobj = Workplace.objects.get(id = request.data['id'],token= request.data['token'])
            serobj = TaskSerializer(data=request.data)
            if serobj.is_valid():
                serobj.save(leader=wobj)
                task = Task.objects.get(id=serobj.data['id'])
                try:
                    uids = request.data['employees'].split(',')
                    if uids:
                        for uid in uids:
                            uobj = Employee.objects.get(id=int(uid))
                            task.employees.add(uobj)
                            task.save()
                except:
                    pass
                return Response({"message":"Task created successfully"},status=200)
            return Response(serobj.errors,status=400)
        except:
            return Response({"message":"Invalid details","status":"400"},status=400)

class TaskDetails(APIView):
    @staticmethod
    def post(request):
        try:
            task = Task.objects.get(id=request.data['task_id'])
            ser = TaskSerializer(task).data
            return Response({"status":"200","message":"Task Details","res":ser},status=200)
        except:
            return Response({"status":"400","message":"Invalid details",},status=400)

class DeleteTask(APIView):
    @staticmethod
    def post(request):
        try:
            wobj = Workplace.objects.get(id = request.data['id'],token= request.data['token'])
            task = Task.objects.get(leader=wobj,id=request.data['task_id'])
            task.delete()
            return Response({"status":"200","message":"Task Deleted"},status=200)
        except:
            return Response({"status":"400","message":"Invalid details",},status=400)

class WorkplaceTaskList(APIView):
    @staticmethod
    def post(request):
        try:
            wobj = Workplace.objects.get(id = request.data['id'],token= request.data['token'])
            tasks = Task.objects.filter(leader=wobj)
            tser = TaskSerializer(tasks,many=True).data
            return Response({"status":"200","message":"Workplace Task List","res":tser},status=200)
        except:
            return Response({"status":"400","message":"Invalid details",},status=400)

class EmployeeTaskList(APIView):
    @staticmethod
    def post(request):
        try:
            eobj = Employee.objects.get(id = request.data['id'],token= request.data['token'])
            # tasks = Task.objects.filter(leader=wobj)
            tasks = eobj.employeeTask.all()
            tser = EmployeeTaskSerializer(tasks,many=True).data
            return Response({"status":"200","message":"Employee Task List","res":tser},status=200)
        except:
            return Response({"status":"400","message":"Invalid details",},status=400)

class ChangeTaskStatus(APIView):
    @staticmethod
    def post(request):
        try:
            wobj = Workplace.objects.get(id = request.data['id'],token= request.data['token'])
            task = Task.objects.get(leader=wobj,id=request.data['task_id'])
            ser = TaskSerializer(task, data=request.data, partial=True)
            if ser.is_valid():
                ser.save()
                return Response({"status":"200","message":"Task Status Changed",},status=200)
            return Response(ser.errors,status=400)
        except:
            return Response({"status":"400","message":"Invalid details",},status=400)

class UpdateTask(APIView):
    @staticmethod
    def post(request):
        try:
            wobj = Workplace.objects.get(id = request.data['id'],token= request.data['token'])
            task = Task.objects.get(id=request.data['task_id'])
            serobj = TaskSerializer(task,data=request.data,partial=True)
            if serobj.is_valid():
                serobj.save()
                try:
                    uids = request.data['employees'].split(',')
                    if uids:
                        for uid in uids:
                            uobj = Employee.objects.get(id=int(uid))
                            task.employees.add(uobj)
                            task.save()
                except:
                    pass
                return Response({"message":"Task updated successfully"},status=200)
            return Response(serobj.errors,status=400)
        except:
            return Response({"message":"Invalid details","status":"400"},status=400)


class Demo(APIView):
    @staticmethod
    def post(request):
        try:
            return Response({"status":"200","message":"Employee added successfully"},status=200)
        except:
            return Response({"status":"400","message":"Invalid details"},status=400)



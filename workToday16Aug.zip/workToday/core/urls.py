"""workToday URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path
from .views import*
urlpatterns = [
    path("organizationList/",OrganizationList.as_view(),name="organizationList"),
    path("workplaceRegistration/",WorkPlaceRegistration.as_view(),name="workplaceRegistration"),
    path("verifyOtp/",Verify_OTP.as_view(),name="verifyOtp"),
    path("logoutWorkplace/",LogOutWorkplace.as_view(),name="logoutWorkplace"),
    path("updateWorkplace/",UpdateWorkplace.as_view(),name="updateWorkplace"),
    path("workplaceDetails/",WorkplaceDetails.as_view(),name="workplaceDetails"),
    path("deleteWorkplace/",DeleteWorkplace.as_view(),name="deleteWorkplace"),
    path("addEmployee/",AddEmployee.as_view(),name="addEmployee"),
    path("employeeList/",EmployeeList.as_view(),name="employeeList"),
    path("employeeDetails/",EmployeeDetails.as_view(),name="employeeDetails"),
    path("updateEmployee/",UpdateEmployee.as_view(),name="updateEmployee"),
    path("employeeLogin/",EmployeeLogin.as_view(),name="employeeLogin"),
    path("logoutEmployee/",LogOutEmployee.as_view(),name="logoutEmployee"),

    # Task urls
    path("addTask/",CreateTask.as_view(),name="addTask"),
    path("updateTask/",UpdateTask.as_view(),name="updateTask"),
    path("taskDetails/",TaskDetails.as_view(),name="taskDetails"),
    path("workplaceTaskList/",WorkplaceTaskList.as_view(),name="workplaceTaskList"),
    path("employeeTaskList/",EmployeeTaskList.as_view(),name="employeeTaskList"),
    path("deleteTask/",DeleteTask.as_view(),name="deleteTask"),
    path("changeTaskStatus/",ChangeTaskStatus.as_view(),name="changeTaskStatus"),
]

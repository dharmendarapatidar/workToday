
from django.utils.translation import gettext_lazy as _
from django.db import models

# Create your models here.
TYPE_CHOICES = (
    ('Team Manager', 'Team Manager'),
    ('Employee','Employee'),
)
GENDER_CHOICES = (
    ('Male', 'Male'),
    ('Female','Female'),
)

class Organization(models.Model):
    name = models.CharField(_('Organization Name'), max_length=500)

    def __str__(self):
        return self.name

class Workplace(models.Model):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE,null=True, blank=True)
    team_size = models.CharField(_("Team Size"),max_length=500,null=True, blank=True)
    workplace_name = models.CharField(_('Workplace Name'), max_length=500,null=True, blank=True)
    phone = models.CharField(_('Phone Number'),max_length=15 ,unique=True,)
    full_name = models.CharField(_('Full Name'), max_length=500, blank=True, null=True)
    email = models.EmailField(_("Email"), null=True, blank=True)
    image = models.ImageField(_('Profile Image'), upload_to='profile-images', null=True, blank=True)
    address = models.CharField(_("Address"),max_length=500,null=True, blank=True)
    created_at = models.DateTimeField(_('Date Joined'), auto_now_add=True)
    updated_at = models.DateTimeField(_('Date Modified'), auto_now=True)
    is_active = models.BooleanField(default=True)
    token = models.CharField(_("Login Token"),max_length=500,blank=True)

    def __str__(self):
        return self.workplace_name

class Employee(models.Model):
    workplace = models.ForeignKey(Workplace, on_delete=models.CASCADE)
    position = models.CharField(_('Position'), max_length=50, choices=TYPE_CHOICES,default="Employee")
    full_name = models.CharField(_('Full Name'), max_length=500, blank=True, null=True)
    email = models.EmailField(_("Email"),unique=True,)
    password = models.CharField(_('Password'),max_length=50)
    phone = models.CharField(_('Phone Number'),max_length=15)
    phone2 = models.CharField(_('Whatsapp Number'),max_length=15,null=True,blank=True)
    image = models.ImageField(_('Profile Image'), upload_to='profile-images', null=True, blank=True)
    address = models.CharField(_("Address"),max_length=500,blank=True)
    created_at = models.DateTimeField(_('Date Joined'), auto_now_add=True)
    updated_at = models.DateTimeField(_('Date Modified'), auto_now=True)
    is_active = models.BooleanField(default=True)
    token = models.CharField(_("Login Token"),max_length=500,blank=True)
    
    def __str__(self):
        try:
            return self.full_name
        except ValueError:
            return str(self.email)

class Task(models.Model):
    leader = models.ForeignKey(Workplace, on_delete=models.CASCADE,)
    employees = models.ManyToManyField(Employee,related_name="employeeTask",)
    priority = models.CharField(_("Priority"),max_length=200,)
    from_date = models.DateField(_("Frome Date"),)
    to_date = models.DateField(_("To Date"),)
    title = models.CharField(_("Title"),max_length=500,)
    description = models.TextField(_("Description"))
    file = models.FileField(_("Task File"),upload_to="task",null=True, blank=True)
    complete = models.BooleanField(_("Complete"), default=False)
    created_at = models.DateTimeField(_("Create Date"),auto_now_add=True)
    updated_at = models.DateTimeField(_("Update Date"),auto_now=True)
    other = models.CharField(_("Other"),max_length=500,null=True, blank=True)

    def __str__(self):
        return self.title

class Attendance(models.Model):
    employee = models.ForeignKey(Employee,on_delete=models.CASCADE)
    created_at = models.DateTimeField(_("Create Date"),auto_now_add=True)
    check_in = models.TimeField(_("Check In Time"),null=True, blank=True)
    check_out = models.TimeField(_("Check Out Time"),null=True, blank=True)
    ciloc = models.CharField(_("Check in location"),max_length=500,null=True, blank=True)
    coloc = models.CharField(_("Check otu location"),max_length=500,null=True, blank=True)
    latci = models.CharField(_("Check in latitude"),max_length=500,null=True, blank=True)
    logci = models.CharField(_("Check in longitude"),max_length=500,null=True, blank=True)
    latci = models.CharField(_("Check out latitude"),max_length=500,null=True, blank=True)
    logci = models.CharField(_("Check out longitude"),max_length=500,null=True, blank=True)
    check_in_image = models.ImageField(_('Check In Image'), upload_to='attendance', null=True, blank=True)
    check_out_image = models.ImageField(_('Check Out Image'), upload_to='attendance', null=True, blank=True)
    other = models.CharField(_("other"),max_length=500,null=True, blank=True)

    def __str__(self):
        return self.employee.full_name

class DailyReport(models.Model):
    task = models.ForeignKey(Task,on_delete=models.CASCADE)
    employee = models.ForeignKey(Employee,on_delete=models.CASCADE)
    created_at = models.DateTimeField(_("Create Date"),auto_now_add=True)
    description = models.TextField(_("Description"))
    file = models.FileField(_("Task File"),upload_to="dailyReports",null=True, blank=True)
    other = models.CharField(_("other"),max_length=500,null=True, blank=True)

    def __str__(self):
        return self.employee.full_name + self.task.title